'use client';

import { Suspense, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ShieldCheck, LockKeyhole, ArrowRight } from 'lucide-react';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const next = useMemo(() => searchParams.get('next') || '/dashboard', [searchParams]);

  const [registrationNumber, setRegistrationNumber] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      if (!registrationNumber.trim()) {
        throw new Error('Please enter your registration number.');
      }
      if (!password) {
        throw new Error('Please enter your password.');
      }

      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          registrationNumber: registrationNumber.trim(),
          password,
        }),
      });

      const payload = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(payload?.error || 'Login failed. Please try again.');
      }

      // The server already set the real session cookies (see
      // /api/auth/login) — the dashboard and every /api/panel/* route read
      // the caller's actual role/post from that cookie via
      // getCurrentUser()/`/api/panel/me`, never from the URL. Do not put
      // role/position in the redirect: a page that trusted query params for
      // authorization was exactly the bug this fix removes.
      const safeNext = next.startsWith('/') ? next : '/dashboard';
      router.push(safeNext);
    } catch (submissionError) {
      setError(submissionError instanceof Error ? submissionError.message : 'Login failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-8rem)] items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-5xl overflow-hidden rounded-3xl border border-border bg-surface shadow-xl">
        <div className="grid md:grid-cols-2">
          <div className="hidden bg-primary/95 p-10 text-white md:flex md:flex-col md:justify-between">
            <div>
              <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <p className="text-sm uppercase tracking-[0.25em] text-blue-100">NEUCC Portal</p>
              <h1 className="mt-4 font-heading text-4xl font-bold">Committee Access</h1>
            </div>

            <div className="space-y-4 text-sm text-blue-100">
              <p>Secure access for executive and election committee members.</p>
              <p>Use your committee credentials to manage events, notices, and governance operations.</p>
            </div>
          </div>

          <div className="p-6 sm:p-8 lg:p-10">
            <div className="mb-8">
              <p className="text-xs uppercase tracking-[0.25em] text-text-muted">Sign in</p>
              <h2 className="mt-2 font-heading text-3xl font-bold text-text-main">Welcome back</h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">

              <div className="space-y-2">
                <label htmlFor="registrationNumber" className="block text-sm font-medium text-text-main">
                  Registration number
                </label>
                <div className="relative">
                  <ShieldCheck className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" />
                  <input
                    id="registrationNumber"
                    type="text"
                    value={registrationNumber}
                    onChange={(event) => setRegistrationNumber(event.target.value)}
                    className="w-full rounded-xl border border-border bg-background py-3 pl-10 pr-3 text-sm text-text-main outline-none transition focus:border-primary"
                    placeholder="2024-12345"
                    autoComplete="username"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="block text-sm font-medium text-text-main">
                  Password
                </label>
                <div className="relative">
                  <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" />
                  <input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    className="w-full rounded-xl border border-border bg-background py-3 pl-10 pr-3 text-sm text-text-main outline-none transition focus:border-primary"
                    placeholder="••••••••"
                    autoComplete="current-password"
                  />
                </div>
              </div>

              {error && (
                <div className="rounded-xl border border-error/30 bg-error/5 px-3 py-2 text-sm text-error">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-hover disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isSubmitting ? 'Signing in...' : 'Sign in'}
                {!isSubmitting && <ArrowRight className="h-4 w-4" />}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="flex min-h-[calc(100vh-8rem)] items-center justify-center bg-background" />}>
      <LoginForm />
    </Suspense>
  );
}
